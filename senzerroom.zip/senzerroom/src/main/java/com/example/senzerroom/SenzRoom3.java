package com.example.senzerroom;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SenzRoom3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_senz_room3);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}
